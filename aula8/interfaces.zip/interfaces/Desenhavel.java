package aula8.interfaces;

import java.awt.Graphics;

public interface Desenhavel {
	public void desenha(Graphics g, int x, int y);
	public int getLargura();
}
